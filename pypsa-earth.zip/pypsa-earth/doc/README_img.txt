# SPDX-FileCopyrightText:  PyPSA-Earth and PyPSA-Eur Authors
#
# SPDX-License-Identifier: CC0-1.0

The images for documentation should be placed into "documentation/doc/img".

The content of the folder "documentation/doc/img/" is copied into "pypsa-earth/doc/img/" during building rst documentation
