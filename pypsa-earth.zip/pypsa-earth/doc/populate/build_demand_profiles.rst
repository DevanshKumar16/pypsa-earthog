.. SPDX-FileCopyrightText:  PyPSA-Earth and PyPSA-Eur Authors
..
.. SPDX-License-Identifier: CC-BY-4.0

.. _load_data:

Rule ``build_demand_profiles``
=============================


.. automodule:: build_demand_profiles
    :noindex:
